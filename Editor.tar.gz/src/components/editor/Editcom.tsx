import React, { ReactElement, useState } from "react";
import parse from "html-react-parser";
import { options } from './data'
import { FaBootstrap, FaItalic, FaUnderline, FaAlignCenter, FaAlignLeft, FaAlignRight, FaLink, FaListOl, FaListUl, FaUndo, FaRedo, FaCamera } from "react-icons/fa";



export function Editcom({ data }: any): ReactElement {
    const [first, setfirst] = useState("")

    console.log("first", first);

    const handlechange = (e: any) => {
        // e.target.style.color = 'grey';
        const newdata = e.target
        console.log("E", newdata)
        setfirst(newdata)
    }


    function onHeading1Click(e: any) {
        const heading: string = e.target.value
        if (heading) {
            document.execCommand('formatBlock', false, `${heading}`);
        }
    }
    const handlebold = () => {

        document.execCommand("bold", true, `${first}`)
    };
    const handleitalic = () => {
        document.execCommand("italic", true, `${first}`);
    };
    function handleunderline() {
        document.execCommand("underline", true, `${first}`);
    }
    const handleOlClick = () => {
        document.execCommand("insertOrderedList", true, `${first}`);
    };
    const handleulClick = () => {
        document.execCommand("insertUnorderedList", true, `${first}`);
    };
    function handleredo() {
        document.execCommand("redo", true, `${first}`);
    }
    function handleundo() {
        document.execCommand("undo", true, `${first}`);
    }
    function handlecreateLink() {
        document.execCommand("CreateLink", false, "http://stackoverflow.com/");
    }
    function handlejustifyCenter() {
        document.execCommand("justifyCenter", true, `${first}`);
    }
    function handlejustifyLeft() {
        document.execCommand("justifyLeft", true, `${first}`);
    }
    function handlejustifyRight() {
        document.execCommand("justifyRight", true, `${first}`);
    }
    function handleInsertImage() {
        var data = window.prompt();
        document.execCommand("insertImage", false, `${data}`);
    }
    return (
        <div className="container">
            <div className="options">
                {/*  Text Format */}
                <button onClick={handlebold} > <FaBootstrap /> </button>
                <button onClick={handleitalic}><FaItalic /></button>
                <button onClick={handleunderline} ><FaUnderline /></button>
                {/*  List */}
                <button onClick={handleOlClick}><FaListOl /></button>
                <button onClick={handleulClick}><FaListUl /></button>
                {/*  Undo/Redo */}
                <button onClick={handleundo}><FaUndo /></button>
                <button onClick={handleredo}><FaRedo /></button>
                {/*  Link */}
                <button onClick={handlecreateLink}><FaLink /></button>
                {/*  Alignment */}
                <button onClick={handlejustifyCenter}><FaAlignCenter /></button>
                <button onClick={handlejustifyLeft}><FaAlignLeft /></button>
                <button onClick={handlejustifyRight}><FaAlignRight /></button>
                {/*  Selection */}
                <select onClick={onHeading1Click} className="button">
                    {options.map((option, i: any) => (
                        <option value={option.value} key={i}>{option.label}</option>
                    ))}
                </select>
                <button onClick={handleInsertImage}><FaCamera /></button>
            </div>
            <div className="text-input" contentEditable={true} suppressContentEditableWarning={true} onClick={handlechange}>
                {parse(data)}
            </div>
        </div>

    );
}
