// import React, { ReactElement, useState } from "react";
// import parse from "html-react-parser";
// import { options } from './data'
// import { FaBootstrap, FaItalic, FaUnderline } from "react-icons/fa";



// export function Imagecom({ data }: any): ReactElement {
//   const [first, setfirst] = useState("")

//   console.log("first", first);

//   const handlechange = (e: any) => {
//     const newdata = e.target
//     console.log("E", newdata)
//     setfirst(newdata)
//   }
//   const handlebold = () => {
//     document.execCommand("bold", true, `${first}`)
//   };
//   const handleitalic = () => {
//     document.execCommand("italic", true, `${first}`);
//   };
//   function handleunderline() {
//     document.execCommand("underline", true, `${first}`);
//   }

//   return (
//     <div className="container">
//       <div className="options">

//         {/*  Text Format */}
//         <button onClick={handlebold}> <FaBootstrap /> </button>
//         <button onClick={handleitalic}><FaItalic /></button>
//         <button onClick={handleunderline} ><FaUnderline /></button>

//         {/*  List */}
//       </div>
//       <div className="text-input" contentEditable={true} suppressContentEditableWarning={true} onMouseUp={handlechange}>
//         {parse(data)}

//       </div>
//       {/* <p>{first}</p> */}
//     </div>

//   );
// }



import { useState } from 'react';

function BoldText({ children, bold }:any) {
  return (
    <span style={{ fontWeight: bold ? 'bold' : 'normal' }}>
      {children}
    </span>
  );
}

export function Imagecom() {
  const [bold, setBold] = useState<any>(false);

  const handleBoldChange = (event:any) => {
    setBold(event.target.checked);
  };

  return (
    <div>
      Coding <BoldText bold={bold}>Beauty</BoldText>
     <button
        
        value={bold}
        onChange={handleBoldChange}
      ></button>

      <label htmlFor="bold">Bold</label>
    </div>
  );
}
